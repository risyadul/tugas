require = require("esm")(module)
module.exports = require('./src/app')